package com.fwcd.sc18.trainer;

import com.fwcd.sc18.trainer.ui.TrainerApp;

public class TrainerMain {
	public static void main(String[] args) {
		new TrainerApp("Trainer", 1280, 720);
	}
}
